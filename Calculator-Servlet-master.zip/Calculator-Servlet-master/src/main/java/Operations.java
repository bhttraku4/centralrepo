enum Operations {
    Addition, Subtraction, Multiplication, Division, None
}